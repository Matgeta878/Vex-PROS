# Goofy-RI3D

Writeup: https://docs.google.com/document/d/1HdKqENHWh6WTbPTh926jqvDW3yEPQfKpOuxzz5v5FYk/edit

VEXforum post: https://www.vexforum.com/t/448x-21s-6...  

RI3D Reveal: https://youtu.be/QJI29QI5COM  

RI3D Documentary: https://youtu.be/BC4ZlIcBB7I
