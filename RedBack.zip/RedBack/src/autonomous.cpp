#include "main.h"
// using namespace okapi;
// pros::ADIGyro gyro('H',0.91);

 void resetDriveEncoders(){
   driveLeftBack.tare_position();
   driveLeftFront.tare_position();
   driveRightBack.tare_position();
   driveRightFront.tare_position();
 }

 double avgDriveEncoderValue(){
   return (fabs(driveLeftFront.get_position())+
   fabs(driveLeftBack.get_position())+
   fabs(driveRightFront.get_position())+
   fabs(driveRightBack.get_position())) / 4;
 }

 void translate(int units,int voltage){
   //Define a direction based on units provided
   int direction = abs(units)/units;//Will either be 1 or -1
   //Reset Motors and Gyros
   resetDriveEncoders();
   gyro.reset();
   //Drive Forward until units are reached
   while(avgDriveEncoderValue() < abs(units)) {
     set_tank(voltage * direction + gyro.get_value(),voltage * direction- gyro.get_value());
     pros::delay(10);
   }
   //Brief Brake
   set_tank(10 * direction,10 * direction);
   pros::delay(50);
   //Set Drive back to neutral
   set_tank(0,0);

 }
/*
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
//  const int driveLeftFront= 1;
//  const int driveLeftBack = 2;
//  const int driveRightFront= 3;
//  const int driveRightBack = 4;
//  const int left_roller = 20;
//  const int right_roller = 11;
//  const auto WHEEL_DIAMETER = 4;
// const auto CHASSIS_WIDTH = 17;
// const double trayP = 0.001;
// const double trayI = 0.0001;
// const double traykD = 0.0001;
// const int TRAY_MOTOR_PORT = 15;
//    auto chassis = ChassisControllerFactory::create(driveLeftBack, driveLeftFront,driveRightBack,driveRightFront);
//    auto trayController = AsyncControllerFactory::posPID(TRAY_MOTOR_PORT, trayP, trayI, traykD);

void autonomous() {
  translate(1000,127);
  // set_tank(100, 100);
  //
  //
  // chassis.moveDistance(0.7493);
  //
  // chassis.moveDistance(-0.7493);
  // // Turn 90 degrees to face second goal
  // chassis.turnAngle(45);
  // chassis.moveDistance(-0.8621045876238);
  // // Drive 1 and a half feet toward second goal
  // chassis.moveDistance(1.5);
  // translate(1000,127);

}
