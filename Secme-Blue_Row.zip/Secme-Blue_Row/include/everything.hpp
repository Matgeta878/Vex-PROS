
#include "main.h"
extern pros::Motor arm;
extern pros::Motor tray;
extern pros::Motor right_roller;
extern pros::Motor left_roller;
extern pros::Motor driveRightFront;
extern pros::Motor driveRightBack;
extern pros::Motor driveLeftFront;
extern pros::Motor driveLeftBack;
extern okapi::DefaultOdomChassisController drivetrain;
extern pros::Imu imu_sensor;
// imu_sensor.reset();
//extern pros::Imu imu;
